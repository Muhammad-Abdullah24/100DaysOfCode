import heapq

grid = [
    ["_", "_", "_", "_", "_"],
    ["_", "X", "_", "X", "_"],
    ["_", "X", "_", "_", "_"],
    ["_", "_", "X", "X", "_"],
    ["_", "_", "_", "_", "_"]
]

ROWS, COLS = 5, 5

def get_neighbors(node):
    i, j = node
    neighbors = []
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    for di, dj in directions:
        ni, nj = i + di, j + dj
        if 0 <= ni < ROWS and 0 <= nj < COLS and grid[ni][nj] != "X":
            neighbors.append((ni, nj))
    return neighbors

# Manhattan Distance heuristic
def heuristic(a, b):
    (x1, y1), (x2, y2) = a, b
    return abs(x1 - x2) + abs(y1 - y2)

def A_star(start, goal):
    frontier = []
    heapq.heappush(frontier, (0, start))  # priority queue
    came_from = {start: None}
    g_score = {start: 0}

    while frontier:
        _, current = heapq.heappop(frontier)

        if current == goal:
            # reconstruct path
            path = []
            while current is not None:
                path.append(current)
                current = came_from[current]
            return path[::-1]

        for neighbor in get_neighbors(current):
            new_cost = g_score[current] + 1  # cost of one step
            if neighbor not in g_score or new_cost < g_score[neighbor]:
                g_score[neighbor] = new_cost
                f_score = new_cost + heuristic(neighbor, goal)
                heapq.heappush(frontier, (f_score, neighbor))
                came_from[neighbor] = current
    return None

# Run A*
start, goal = (0, 0), (4, 4)
path = A_star(start, goal)

print("Grid:")
for row in grid:
    print(" ".join(row))

print("\nA* Path found:" if path else "\nNo path found.")
print(path)
