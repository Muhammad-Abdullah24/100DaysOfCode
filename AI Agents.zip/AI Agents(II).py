import random

choice = ["clean", "dirt"]
matrix = [[random.choice(choice) for _ in range(2)] for _ in range(2)]

state = {}

for row in matrix:
    print(row)

def model_based_agent(percept: str, location: tuple[int, int]) -> str:
    i, j = location

    state[(i, j)] = percept

    if state[(i, j)] == "dirt":
        return "suck"

    for (x, y) in [(0,0), (0,1), (1,0), (1,1)]:
        if (x, y) not in state or state[(x, y)] == "dirt":

            if x < i: return "Up"
            if x > i: return "Down"
            if y < j: return "Left"
            if y > j: return "Right"

    return "NoOp"

def move(direction: str, i: int, j: int) -> tuple[int, int]:
    if direction == "Left" and j > 0:
        j -= 1
    elif direction == "Right" and j < 1:
        j += 1
    elif direction == "Up" and i > 0:
        i -= 1
    elif direction == "Down" and i < 1:
        i += 1
    return i, j

i, j = 0, 0

for steps in range(10):
    percept = matrix[i][j]
    action = model_based_agent(percept, (i,j))

    if action == "suck":
        matrix[i][j] = "clean"
        state[(i,j)] = "clean"
        print(f"Step {steps}: Sucked at {(i,j)}")
    elif action == "NoOp":
        print(f"Step {steps}: NoOp (everything clean & visited)")
        break
    else:
        i, j = move(action, i, j)
        print(f"Step {steps}: Moved {action} to {(i,j)}")

print("\nFinal Matrix:")
for row in matrix:
    print(row)

print("\nInternal State:", state)
