from collections import deque

grid = [
    ["_", "_", "_", "_", "_"],
    ["_", "X", "_", "X", "_"],
    ["_", "X", "_", "_", "_"],
    ["_", "_", "X", "X", "_"],
    ["_", "_", "_", "_", "_"]
]

ROWS, COLS = 5, 5

def get_neighbors(node):
    i, j = node
    neighbors = []
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    for di, dj in directions:
        ni, nj = i + di, j + dj
        if 0 <= ni < ROWS and 0 <= nj < COLS and grid[ni][nj] != "X":
            neighbors.append((ni, nj))
    return neighbors

def BFS(start, goal):
    frontier = deque([start])  # queue
    explored = set()
    parent = {start: None}

    while frontier:
        node = frontier.popleft()
        if node == goal:

            path = []
            while node is not None:
                path.append(node)
                node = parent[node]
            return path[::-1]
        explored.add(node)
        for neighbor in get_neighbors(node):
            if neighbor not in explored and neighbor not in frontier:
                frontier.append(neighbor)
                parent[neighbor] = node
    return None

start = (0, 0)
goal = (4, 4)
path = BFS(start, goal)

print("Grid:")
for row in grid:
    print(" ".join(row))

print("\nPath found:" if path else "\nNo path found.")
print(path)
