import random

choice = ["clean", "dirt"]
matrix = [[" "] * 2 for i in range(2)]

state = {
    "visited" : []
}

for i in range(2):
    for j in range(2):
        matrix[i][j] = random.choice(choice)

print("Initial Matrix:")
for row in matrix:
    print(row)

def reflexive_agent(percept: str) -> str:
    choice = ["Left", "Right", "Up", "Down"]
    if percept == "dirt":
        action = "suck"
    else:
        action = random.choice(choice)
    return action

def move(direction: str, i: int, j: int) -> tuple[int, int]:
    if direction == "Left":
        if j > 0:
            j -= 1
    elif direction == "Right":
        if j < 1:
            j += 1
    elif direction == "Up":
        if i > 0:
            i -= 1
    elif direction == "Down":
        if i < 1:
            i += 1
    return i, j

i, j = 0, 0

for steps in range(10):
    percept = matrix[i][j]
    action = reflexive_agent(percept)

    if action == "suck":
        matrix[i][j] = "clean"
        state["visited"].append((i, j))
        print(f"Step {steps}: Sucked dirt at {(i, j)}")
    else:
        old_pos = (i, j)
        i, j = move(action, i, j)
        print(f"Step {steps}: Moved {action} from {old_pos} to {(i, j)}")

print("\nFinal Matrix:")
for row in matrix:
    print(row)

print("\nVisited cells:", state["visited"])
